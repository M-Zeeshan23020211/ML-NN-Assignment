import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.preprocessing import LabelEncoder, StandardScaler
import seaborn as sns
import matplotlib.pyplot as plt
import joblib

import zipfile
with zipfile.ZipFile('titanic.zip', 'r') as zip_ref:
    zip_ref.extractall('titanic')

# Step 3: Load the dataset
df = pd.read_csv('titanic/train.csv')

# Step 4: Data Preprocessing
# Fill missing values
df['Age'].fillna(df['Age'].mean(), inplace=True)
df['Embarked'].fillna(df['Embarked'].mode()[0], inplace=True)
df['Fare'].fillna(df['Fare'].mean(), inplace=True)

# Encode categorical features using LabelEncoder
le = LabelEncoder()
df['Sex'] = le.fit_transform(df['Sex'])
df['Embarked'] = le.fit_transform(df['Embarked'])

# Create a new feature "FamilySize" based on SibSp and Parch
df['FamilySize'] = df['SibSp'] + df['Parch']

# Select features (X) and target variable (y)
X = df[['Pclass', 'Sex', 'Age', 'SibSp', 'Parch', 'Fare', 'Embarked', 'FamilySize']]
y = df['Survived']

# Step 5: Feature Scaling (Optional for better performance)
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Step 6: Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# Step 7: Hyperparameter Tuning with GridSearchCV
param_grid = {
    'n_estimators': [100, 200, 300],
    'max_depth': [None, 10, 20, 30],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'bootstrap': [True, False]
}

# Apply GridSearchCV
rf_model = RandomForestClassifier(random_state=42)
grid_search = GridSearchCV(estimator=rf_model, param_grid=param_grid, cv=5, n_jobs=-1, verbose=2)
grid_search.fit(X_train, y_train)

# Step 8: Best Model from GridSearchCV
best_rf_model = grid_search.best_estimator_
print(f'Best Hyperparameters: {grid_search.best_params_}')

# Step 9: Evaluate the model using cross-validation
cv_scores = cross_val_score(best_rf_model, X_train, y_train, cv=5)
print(f'Cross-Validation Scores: {cv_scores}')
print(f'Mean Cross-Validation Score: {cv_scores.mean()}')

# Step 10: Evaluate the model on the test data
y_pred = best_rf_model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f'Accuracy on Test Set: {accuracy * 100:.2f}%')

# Classification report and confusion matrix
print('Classification Report:')
print(classification_report(y_test, y_pred))

cm = confusion_matrix(y_test, y_pred)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=['Died', 'Survived'], yticklabels=['Died', 'Survived'])
plt.title('Confusion Matrix')
plt.show()

# Step 11: Save the trained model using joblib
joblib.dump(best_rf_model, 'best_rf_model_advanced.pkl')
print("Model saved as 'best_rf_model_advanced.pkl'")

# Step 12: Function for user input prediction
def predict_survival():
    print("\nPlease enter the following details of a passenger:")

    try:
        pclass = int(input("Passenger Class (1, 2, or 3): "))
        sex = input("Sex (male/female): ").lower()
        sex = 1 if sex == 'male' else 0  # Convert sex to 1 (male) or 0 (female)
        age = float(input("Age: "))
        sibsp = int(input("Number of Siblings/Spouses aboard: "))
        parch = int(input("Number of Parents/Children aboard: "))
        fare = float(input("Fare: "))
        embarked = input("Embarked (C = Cherbourg, Q = Queenstown, S = Southampton): ").lower()
        embarked = {'c': 0, 'q': 1, 's': 2}.get(embarked, 2)  # Convert Embarked to integers
        family_size = sibsp + parch

        # Standardize the input data using the same scaler as the training data
        user_input = np.array([[pclass, sex, age, sibsp, parch, fare, embarked, family_size]])
        user_input_scaled = scaler.transform(user_input)

        # Make a prediction using the trained model
        prediction = best_rf_model.predict(user_input_scaled)
        
        if prediction[0] == 1:
            print("\nThe passenger survived.")
        else:
            print("\nThe passenger did not survive.")
    
    except ValueError:
        print("Invalid input, please enter valid values.")

# Step 13: Run the prediction function
predict_survival()
