import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import LabelEncoder
import seaborn as sns
import matplotlib.pyplot as plt


# Unzip the downloaded file
import zipfile
with zipfile.ZipFile('titanic.zip', 'r') as zip_ref:
    zip_ref.extractall('titanic')

# Step 2: Load the Titanic dataset
df = pd.read_csv('titanic/train.csv')

# Step 3: Preprocess the data
# Fill missing values
df['Age'].fillna(df['Age'].mean(), inplace=True)
df['Embarked'].fillna(df['Embarked'].mode()[0], inplace=True)

# Encode categorical features using LabelEncoder
le = LabelEncoder()
df['Sex'] = le.fit_transform(df['Sex'])
df['Embarked'] = le.fit_transform(df['Embarked'])

# Select features (X) and target variable (y)
X = df[['Pclass', 'Sex', 'Age', 'SibSp', 'Parch', 'Fare', 'Embarked']]
y = df['Survived']

# Step 4: Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 5: Train the Random Forest Classifier
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
rf_model.fit(X_train, y_train)

# Step 6: Evaluate the model
y_pred = rf_model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f'Accuracy of the Random Forest model: {accuracy * 100:.2f}%')

# Step 7: Allow user input for prediction
def predict_survival():
    print("\nPlease enter the following details of a passenger:")

    try:
        pclass = int(input("Passenger Class (1, 2, or 3): "))
        sex = input("Sex (male/female): ").lower()
        sex = 1 if sex == 'male' else 0  # Convert sex to 1 (male) or 0 (female)
        age = float(input("Age: "))
        sibsp = int(input("Number of Siblings/Spouses aboard: "))
        parch = int(input("Number of Parents/Children aboard: "))
        fare = float(input("Fare: "))
        embarked = input("Embarked (C = Cherbourg, Q = Queenstown, S = Southampton): ").lower()
        embarked = {'c': 0, 'q': 1, 's': 2}.get(embarked, 2)  # Convert Embarked to integers

        # Make a prediction based on user input
        user_input = np.array([[pclass, sex, age, sibsp, parch, fare, embarked]])
        prediction = rf_model.predict(user_input)
        
        if prediction[0] == 1:
            print("\nThe passenger survived.")
        else:
            print("\nThe passenger did not survive.")
    
    except ValueError:
        print("Invalid input, please enter valid values.")

# Step 8: Run the prediction function
predict_survival()
