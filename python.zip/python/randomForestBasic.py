# Import necessary libraries
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Function to load and train the model
def train_random_forest():
    # Load dataset (for example, Iris dataset)
    data = load_iris()
    X = data.data
    y = data.target

    # Split dataset into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

    # Initialize the Random Forest model
    rf = RandomForestClassifier(n_estimators=100, random_state=42)

    # Train the model
    rf.fit(X_train, y_train)

    # Evaluate the model on the test set
    y_pred = rf.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)

    return rf, accuracy

# Function to make predictions based on user input
def make_predictions(model):
    print("\nPlease enter the feature values for prediction (e.g., sepal length, sepal width, petal length, petal width):")
    
    # Ask the user for input values
    try:
        # Accept user input for the features
        input_values = input("Enter the values separated by spaces: ").split()
        input_values = [float(i) for i in input_values]  # Convert input to float

        # Reshape input to match the model's expected format
        input_array = np.array(input_values).reshape(1, -1)

        # Make prediction
        prediction = model.predict(input_array)
        print(f"\nPrediction: {prediction[0]} (class label)")
        
    except ValueError:
        print("\nError: Please ensure you input numeric values for each feature.")

# Main function to interact with the user
def main():
    print("Training Random Forest model...")
    
    # Train the model
    model, accuracy = train_random_forest()
    
    print(f"\nModel trained. Accuracy on the test data: {accuracy * 100:.2f}%")
    
    # Ask the user if they want to make a prediction
    while True:
        choice = input("\nDo you want to enter new data for prediction? (yes/no): ").strip().lower()
        if choice == 'yes':
            make_predictions(model)
        elif choice == 'no':
            print("\nExiting the program.")
            break
        else:
            print("\nInvalid choice, please enter 'yes' or 'no'.")

# Run the main function
if __name__ == "__main__":
    main()
